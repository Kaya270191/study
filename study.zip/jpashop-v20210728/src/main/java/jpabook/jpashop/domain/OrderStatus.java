package jpabook.jpashop.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
